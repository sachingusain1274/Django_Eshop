from django.db import models
from .product import Product
from .customer import CustomerUser
import datetime

class Order(models.Model):
    product  = models.ForeignKey(Product , on_delete=models.CASCADE)
    customer = models.ForeignKey(CustomerUser , on_delete=models.CASCADE)  #customer id foreign key
    address  = models.CharField(max_length=100 , blank=True)
    phone    = models.CharField(max_length=50 , default = '')
    quantity = models.IntegerField(default=1)
    price    = models.IntegerField()
    date     = models.DateField(default=datetime.datetime.today)
    status   = models.BooleanField(default=False)

    
    def __str__(self):
        return self.product.name


    def place_order(self):
        return self.save()

    
    @staticmethod
    def get_order_by_customer_id(customer_id):
        return Order.objects.filter(customer = customer_id).order_by('-date')