from django.db import models


class CustomerUser(models.Model):
    first_name = models.CharField(max_length=50)
    last_name  = models.CharField(max_length=50)
    mobile     = models.IntegerField()
    email      = models.EmailField()
    password   = models.CharField(max_length=15)


    def __str__(self):
        return self.first_name


    # for registering user 

    def register(self):
        self.save()
    
    @staticmethod
    def get_customer_by_email(email):
        # using try because when we use get method we get whether result or error so to avoid we use try and exception
        try:
            return CustomerUser.objects.get(email=email)
        except:
            return False

            
    # for email checking
    def isExists(self):
        if CustomerUser.objects.filter(email=self.email):
            return True
        else:
            return False