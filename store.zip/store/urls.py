from django.contrib import admin
from django.urls import path
from . import views
from .views import Login,Signup,Index,Cart,Checkout,OrderView
from store.middlewares.auth import auth_middleware


urlpatterns = [

    # path('home/' ,views.index , name='home'),
    path('' ,Index.as_view() , name='home'),
    # path('signup/',views.signup , name='signup'),
    path('login/',Login.as_view() , name='login'),
    path('signup/',Signup.as_view() , name='signup'),
    # path('login/',views.login , name='login'),
    path('signout/',views.signout , name="signout"),
    path('cart',Cart.as_view() , name="cart"),
    path('checkout',Checkout.as_view() , name="checkout"),

    path('order',auth_middleware(OrderView.as_view()) , name = "order" ),

]
