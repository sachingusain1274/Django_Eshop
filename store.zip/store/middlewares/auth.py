from django.shortcuts import render,redirect


def auth_middleware(get_response):

    def middleware(request):
        # print('auth',request.session.get('customer_id'))

        # print(request.META['PATH_INFO'])

        returnUrl = request.META['PATH_INFO']   #this shows orders page redirect login page so we get order page url here

        if not request.session.get('customer_id'):
            return redirect(f'login?return_url={returnUrl}')
            
        response = get_response(request)
        return response
    
    return middleware