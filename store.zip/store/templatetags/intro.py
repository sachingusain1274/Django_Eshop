# this is a random file 

# introduction

'''here we create a templatetags folder in app where is use template filter 
inside this folder we create a python file and then we will write a code and that code we will use in template html file'''