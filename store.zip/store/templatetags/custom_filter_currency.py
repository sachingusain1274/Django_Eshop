from django import template

register = template.Library()   




@register.filter(name="currency")     #write any name u want 
def currency(number):
    return "₹ "+str(number)


