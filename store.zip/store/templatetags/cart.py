from django import template

register = template.Library()   




@register.filter(name="is_in_cart")     #write any name u want 
def is_in_cart(product , cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:   #id is a string
            return True
    print(keys)
    return False


@register.filter(name="cart_quantity")     #write any name u want 
def cart_quantity(product , cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:   #id is a string
           return cart.get(id)
    return 0

# function for total price showing in cart.html

@register.filter(name='total_price')
def total_price(product,cart):
    return product.price * cart_quantity(product,cart)


@register.filter(name='grand_total')
def grand_total(product,cart):  #here product is a list of product
    sum = 0
    for p in product:
        sum+= total_price(p,cart)
    return sum


@register.filter(name='multiplye')
def multiplye(a,b):  #for order.html -->for quantity * total
    return a*b