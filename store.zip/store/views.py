from django.shortcuts import render,redirect,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password #for converting paswd hash 
from .models.product import Product
from .models.category import Category
from .models.customer import CustomerUser
from .models.orders import Order
from django.views import View
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator


# Create your views here.
           
# for checking
# print(make_password("12345"))
# print(check_password("12345",'pbkdf2_sha256$216000$rK1l5J305VxS$ZCeMbTdeLxg7wwVkF+eameamH+FOm5JR1h0WwLcMVCY='))


class Index(View):

    #POST request on this page to get product id while clicking on add to card
    def post(self,request):
        product = request.POST.get('product_id')
        remove_product = request.POST.get('remove_cart_product')     #that value come from plus minus form

        # print(product)

        cart = request.session.get('cart')
        if cart: 
            quantity = cart.get(product)  #in (product) is product id . checking cart has product or not
            if quantity:
                if remove_product:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity-1
                else:
                    cart[product] = quantity+1

            else:
                #if we have cart then append cart value
                cart[product] = 1

        else:
            #if cart not present so we create a cart and putting value of cart
            cart = {}               
            cart[product] = 1
        
        request.session['cart'] = cart          #save data in session
        print(request.session['cart'])
        return redirect('home')

    def get(self,request):
        cart = request.session.get('cart')  #when cart delete through session
        if not cart:
            request.session['cart'] = {}

        # products = Product.get_all_products()
        products = None
        category = Category.get_all_category()
        categoryID = request.GET.get('category')   #('category')=> model name
        if categoryID:
            products = Product.get_all_products_by_category_id(categoryID)
        else:
            products = Product.get_all_products()

        print('current user =', request.session.get('customer_email'))
        # print(products)
        return render(request,'index.html',{'products': products ,'category':category})

'''def index(request):
    # products = Product.get_all_products()
    products = None
    category = Category.get_all_category()
    categoryID = request.GET.get('category')   #('category')=> model name
    if categoryID:
        products = Product.get_all_products_by_category_id(categoryID)
    else:
        products = Product.get_all_products()

    # print(products)
    return render(request,'index.html',{'products': products ,'category':category})'''


'''def validationCustomer(customer):
    error_message = None      # message for error

    if(not customer.first_name):
        error_message = 'first name is required!'
    elif len(customer.first_name) < 4:
        error_message = 'First Name should be gretar than or eual to 4 character'

    if not customer.last_name:
        error_message = 'last name is required!'
    elif len(customer.last_name) < 4:
        error_message = 'last Name should be gretar than or eual to 4 character'
    
    if not customer.mobile:
        error_message = 'mobile filed required'
    elif len(customer.mobile) < 10 or len(customer.mobile) > 10:
        error_message = 'Phone field number either less or more'
        
        
    if not customer.email:
        error_message = 'email Field required !'

    #email valdiation
    if customer.isExists():
        error_message = 'This Email Address already exits !'

    if not customer.password:
        error_message = 'Password field is required'
    elif len(customer.password) > 15 or len(customer.password) < 6:
        error_message ="password is too long"
    
    return error_message'''



'''def registerCustomer(request):
    firstname = request.POST.get('first_name')
    lastname  = request.POST.get('last_name')
    phone     = request.POST.get('phone')
    email     = request.POST.get('email')
    password  = request.POST.get('password')
    print(firstname,lastname,phone,email,password)

    # validation from server side
    # for recovery data during error
    value = {
        'firstname':firstname,
        'lastname':lastname,
        'phone':phone,
        'email':email
    }
    # for register user...(saving)
    customer = CustomerUser(first_name = firstname,last_name=lastname,mobile=phone,password=password,email=email)
    
    error_message = validationCustomer(customer)   #for return error message
        
    if not error_message:
        #coverting password into hash password
        customer.password = make_password(customer.password)
        customer.register()      # customer.save() we can use save method
        return redirect('signup')
    else:
        data = {
            "error" : error_message,
            "values" : value
        }
        return render(request,'signup.html',data)'''
    # return HttpResponse(request.POST.get('password'))    for getting input data

class Signup(View):


    def get(self,request):
        if request.method == 'GET':
            return render(request,'signup.html')

    
    def post(self,request):
        firstname = request.POST.get('first_name')
        lastname  = request.POST.get('last_name')
        phone     = request.POST.get('phone')
        email     = request.POST.get('email')
        password  = request.POST.get('password')
        # print(firstname,lastname,phone,email,password)

        # validation from server side
        # for recovery data during error
        value = {
            'firstname':firstname,
            'lastname':lastname,
            'phone':phone,
            'email':email
        }
        # for register user...(saving)
        customer = CustomerUser(first_name = firstname,last_name=lastname,mobile=phone,password=password,email=email)
        
        error_message = self.validationCustomer(customer)   #for return error message
            
        if not error_message:
            #coverting password into hash password
            customer.password = make_password(customer.password)
            customer.register()      # customer.save() we can use save method
            return redirect('login')
        else:
            data = {
                "error" : error_message,
                "values" : value
            }
            return render(request,'signup.html',data)


    def validationCustomer(self,customer):
        error_message = None      # message for error

        if(not customer.first_name):
            error_message = 'first name is required!'
        elif len(customer.first_name) < 4:
            error_message = 'First Name should be gretar than or eual to 4 character'

        if not customer.last_name:
            error_message = 'last name is required!'
        elif len(customer.last_name) < 4:
            error_message = 'last Name should be gretar than or eual to 4 character'
        
        if not customer.mobile:
            error_message = 'mobile filed required'
        elif len(customer.mobile) < 10 or len(customer.mobile) > 10:
            error_message = 'Phone field number either less or more'
            
            
        if not customer.email:
            error_message = 'email Field required !'

        #email valdiation
        if customer.isExists():
            error_message = 'This Email Address already exits !'

        if not customer.password:
            error_message = 'Password field is required'
        elif len(customer.password) > 15 or len(customer.password) < 6:
            error_message ="password is too long"
        
        return error_message

'''def signup(request):
    print(request.method)
    if request.method == 'GET':
        return render(request,'signup.html')
    else:
        return registerCustomer(request)'''

    # else:
        # firstname = request.POST.get('first_name')
        # lastname  = request.POST.get('last_name')
        # phone     = request.POST.get('phone')
        # email     = request.POST.get('email')
        # password  = request.POST.get('password')
        # print(firstname,lastname,phone,email,password)

        # validation from server side
        # for recovery data during error
        # value = {
        #     'firstname':firstname,
        #     'lastname':lastname,
        #     'phone':phone,
        #     'email':email
        # }
        # error_message = None      # message for error

        # for register user...(saving)
        # customer = CustomerUser(first_name = firstname,last_name=lastname,mobile=phone,password=password,email=email)

        # if(not firstname):
        #     error_message = 'first name is required!'
        # elif len(firstname) < 4:
        #     error_message = 'First Name should be gretar than or eual to 4 character'

        # if not lastname:
        #     error_message = 'last name is required!'
        # elif len(lastname) < 4:
        #     error_message = 'last Name should be gretar than or eual to 4 character'
        
        # if not phone:
        #     error_message = 'mobile filed required'
        # elif len(phone) < 10 or len(phone) > 10:
        #     error_message = 'Phone field number either less or more'
        
        
        # if not email:
        #     error_message = 'email Field required !'

        #email valdiation
        # if customer.isExists():
        #     error_message = 'This Email Address already exits !'

        # if not password:
        #     error_message = 'Password field is required'
        # elif len(password) > 15 or len(password) < 6:
        #     error_message ="password is too long"
        
        # error_message = validationCustomer(customer)   #for return error message
            
        # if not error_message:
            # for register user...(saving)
            # customer = CustomerUser(first_name = firstname,last_name=lastname,mobile=phone,password=password,email=email)

            # customer.save()   we can use save method but we define function in model se we call it

            #coverting password into hash password
        #     customer.password = make_password(customer.password)
        #     customer.register()
        #     return redirect('signup')
        # else:
        #     data = {
        #         "error" : error_message,
        #         "values" : value
        #     }
        #     return render(request,'signup.html',data)
        # return HttpResponse(request.POST.get('password'))    for getting input data

class Login(View):
    
    return_url = None    #for orders page navigation

    def get(self,request):
        Login.return_url = request.GET.get('return_url')
        return render(request,'login.html')
    
    def post(self,request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = CustomerUser.get_customer_by_email(email)
        error_message = None
        if customer:
            result = check_password(password,customer.password)
            if result:
                request.session['customer_id'] = customer.id #intialize session /customer id
                request.session['customer_email'] = customer.email 
                
                #for orders page navigation
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)   #HttpResponseRedirect is used for redirect page with the help of url other wise we used redirect.
                else:
                    Login.return_url = None     #for reset return_url for next time 
                    return redirect('home')
            else:
                error_message = 'Email or Password Invalid'
        else:
            error_message = 'Email or Password Invalid'
        
        return render(request,'login.html',{'error':error_message})


# def login(request):
    # if request.method == 'GET':
    #     return render(request,'login.html')
    # else:
    #     email = request.POST.get('email')
    #     password = request.POST.get('password')
    #     customer = CustomerUser.get_customer_by_email(email)
    #     error_message = None
    #     if customer:
    #         result = check_password(password,customer.password)
    #         if result:
    #             return redirect('home')
    #         else:
    #             error_message = 'Email or Password Invalid !'
    #     else:
    #         error_message = 'Email or Password Invalid !'
    #     print(customer)
    #     print(email,'and',password)
    #     return render(request,'login.html',{'error':error_message})


def signout(request):
    request.session.clear()
    return redirect('login')

# Showing Products in cart page
class Cart(View):

    def get(self, request):
        ids = list(request.session.get('cart').keys())
        products = Product.get_product_by_ids(ids)
        print(products)
        return render(request,'cart.html',{'products':products})


#orders

class Checkout(View):

    def post(self,request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_product_by_ids(list(cart.keys())) #getting price and quantity from database

        for p in products:
            order = Order(
                            customer = CustomerUser(id= customer) ,
                            product = p, 
                            price = p.price,
                            address = address,
                            phone = phone,
                            quantity = cart.get(str(p.id))
                        )
            order.place_order()
        request.session['cart'] = {}
        print('###################',   address,phone,customer ,cart,products)
        return redirect('cart')


class OrderView(View):

    # @method_decorator(auth_middleware)
    def get(self,request):
        customer = request.session.get('customer_id')    #id customer
        order = Order.get_order_by_customer_id(customer)
        print(customer , order)
        return render(request,'order.html',{'orders':order})
    