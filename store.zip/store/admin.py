from django.contrib import admin
from store.models.product import Product
from store.models.category import Category
from store.models.customer import CustomerUser
from store.models.orders import Order


#admin table configuration

class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']

# class AdminCategory(admin.ModelAdmin):
#     list_display = ['name']

class AdminCustomerUser(admin.ModelAdmin):
    list_display = ['first_name','last_name' ,'email','mobile']

# Register your models here.
admin.site.register(Product,AdminProduct)
admin.site.register(Category)
admin.site.register(CustomerUser,AdminCustomerUser)
admin.site.register(Order)


